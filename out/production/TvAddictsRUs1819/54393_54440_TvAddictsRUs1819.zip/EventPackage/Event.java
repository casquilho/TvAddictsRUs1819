/**
 * @author Joao Casquilho 54440
 * @author Andre Lisboa 54393
 */
package EventPackage;

public interface Event {

    String getEvent();

    int getSeason();

    int getEpisode();
}
