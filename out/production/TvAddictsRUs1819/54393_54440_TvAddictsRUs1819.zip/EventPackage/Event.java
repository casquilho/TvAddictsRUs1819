package EventPackage;

public interface Event {

    String getEvent();

    int getSeason();

    int getEpisode();
}
