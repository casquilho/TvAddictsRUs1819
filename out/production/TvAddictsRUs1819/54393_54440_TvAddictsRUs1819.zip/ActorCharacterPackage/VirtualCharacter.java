/**
 * @author Joao Casquilho 54440
 * @author Andre Lisboa 54393
 */
package ActorCharacterPackage;

public interface VirtualCharacter {

    String getCharName();

    String getCompanyCGI();
}
