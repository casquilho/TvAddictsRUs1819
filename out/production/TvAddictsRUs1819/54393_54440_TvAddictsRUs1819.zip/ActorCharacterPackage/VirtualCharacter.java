package ActorCharacterPackage;

public interface VirtualCharacter {

    String getCharName();

    String getCompanyCGI();
}
