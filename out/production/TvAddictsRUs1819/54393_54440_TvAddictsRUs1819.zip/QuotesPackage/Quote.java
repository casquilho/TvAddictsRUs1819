package QuotesPackage;

public interface Quote {

    String getQuote();

    public String getCharName();

    int getSeason();

    int getEpisode();
}
