/**
 * @author Joao Casquilho 54440
 * @author Andre Lisboa 54393
 */
package QuotesPackage;

public interface Quote {

    String getQuote();

    public String getCharName();

    int getSeason();

    int getEpisode();
}
