package CGICompaniesPackage;

public interface CGICompany {

    int getProfit();

    void addCharacter(int value);

    int getNumberChars();

    String getName();

    void addProfit(int value);


}
