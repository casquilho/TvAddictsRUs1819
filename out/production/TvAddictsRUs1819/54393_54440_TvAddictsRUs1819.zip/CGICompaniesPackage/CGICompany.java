/**
 * @author Joao Casquilho 54440
 * @author Andre Lisboa 54393
 */
package CGICompaniesPackage;

public interface CGICompany {

    int getProfit();

    void addCharacter(int value);

    int getNumberChars();

    String getName();

    void addProfit(int value);


}
